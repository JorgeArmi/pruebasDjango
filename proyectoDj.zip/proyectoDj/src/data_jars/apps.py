from django.apps import AppConfig


class DataJarsConfig(AppConfig):
    name = 'data_jars'
