#!C:\Users\jorge.armisen\Desktop\proyectoDj\entorno_virtual\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
