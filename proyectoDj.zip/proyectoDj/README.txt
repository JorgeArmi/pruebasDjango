Pruebas con Django y posible Manual para documentar todos los pasos y mejoras que se vayan haciendo.

En primer luhar para lograr pasarle los datos de la BBDD a la plantilla HTML es necesario, declarara un queryset.
Hay que pasarselo en el contexto y devolverno con el metodo render para poder  cargar la tabla en el HTML.
